using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class PredictGamePerformance : MonoBehaviour
{
    [SerializeField]
    private Text resultText; // Text UI to display the prediction result

    // Function to send the prediction request to Flask API
    public void PredictPerformance(int level, float timeTaken, int totalErrors, float finalScore)
    {
        StartCoroutine(SendPredictionRequest(level, timeTaken, totalErrors, finalScore));
    }

    // Coroutine to handle the POST request to Flask
    private IEnumerator SendPredictionRequest(int level, float timeTaken, int totalErrors, float finalScore)
    {
        // Prepare the request data
        string jsonData = "{\"input_data\": [" + level + ", " + timeTaken + ", " + totalErrors + ", " + finalScore + "]}";

        // Create UnityWebRequest
        using (UnityWebRequest request = new UnityWebRequest("http://127.0.0.1:5000/predict", "POST"))
        {
            byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");

            // Send the request and wait for the response
            yield return request.Send();

            // Check for network errors or HTTP errors
            if (request.isNetworkError || request.isHttpError)
            {
                // Handle errors
                Debug.LogError("Error in prediction request: " + request.error);
                resultText.text = "Prediction failed!";
            }
            else
            {
                // Parse the response JSON and update the UI
                string jsonResponse = request.downloadHandler.text;
                PredictionResponse predictionResponse = JsonUtility.FromJson<PredictionResponse>(jsonResponse);

                // Get the prediction value
                float prediction = predictionResponse.prediction[0];

                // Check prediction value and display corresponding performance message
                if (prediction == 0)
                {
                    resultText.text = "Performance is Bad";
                }
                else if (prediction == 1)
                {
                    resultText.text = "Performance is Medium";
                }
                else if (prediction == 2)
                {
                    resultText.text = "Performance is Good";
                }
                else
                {
                    resultText.text = "Unknown performance level";
                }
                yield return new WaitForSeconds(5f);
                resultText.text = "Prediction will appear";
            }
        }
    }

    // Class to represent the response body
    [System.Serializable]
    public class PredictionResponse
    {
        public float[] prediction;
    }
}
