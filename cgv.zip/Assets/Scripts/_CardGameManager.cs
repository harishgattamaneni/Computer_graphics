﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class _CardGameManager : MonoBehaviour
{
    public static _CardGameManager Instance;
    public static int gameSize = 2;
    [SerializeField]
    private GameObject prefab;
    [SerializeField]
    private GameObject cardList;
    [SerializeField]
    private Sprite cardBack;
    [SerializeField]
    private Sprite[] sprites;
    private _Card[] cards;
    [SerializeField]
    private GameObject panel;
    [SerializeField]
    private GameObject info;
    [SerializeField]
    private _Card spritePreload;
    [SerializeField]
    private Text sizeLabel;
    [SerializeField]
    private Slider sizeSlider;
    [SerializeField]
    private Text timeLabel;
    [SerializeField]
    private Text resultText; // UI Text to display prediction result

    private float time = 0f;
    private int correctAttempts = 0;
    private int totalAttempts = 0;
    private int errors = 0; // Number of incorrect guesses
    private float score = 0;

    [SerializeField]
    private RectTransform[] highlightMasks;

    private int spriteSelected;
    private int cardSelected;
    private int cardLeft;
    private bool gameStart;
    private static int gameId = 1; // Unique game ID

    private string resultsFilePath;

    void Awake()
    {
        Instance = this;

        // Construct the file path for saving game results
        resultsFilePath = Path.Combine(Application.persistentDataPath, "results.csv");
        Debug.Log("Results file path: " + resultsFilePath);
        InitializeCSV();
    }

    void Start()
    {
        gameStart = false;
        sizeSlider.maxValue = 6;
        panel.SetActive(false);
        time = 0f;
        UpdateTimeLabel();
    }

    private void InitializeCSV()
    {
        // Create the CSV file with headers if it doesn't exist
        if (!File.Exists(resultsFilePath))
        {
            try
            {
                string headers = "GameID,Level,TimeTaken,Errors,FinalScore\n";
                File.WriteAllText(resultsFilePath, headers);
                Debug.Log("CSV initialized successfully with headers.");
            }
            catch (IOException e)
            {
                Debug.LogError("Error initializing CSV: " + e.Message);
            }
        }
    }

    private void SaveGameResults()
    {
        // Format game results for saving
        string result = string.Format("{0},{1},{2:F0},{3},{4:F2}\n", gameId, gameSize, time, errors, score);

        try
        {
            // Append the result to the CSV file
            File.AppendAllText(resultsFilePath, result);
            Debug.Log("Game results saved: " + result);
        }
        catch (IOException e)
        {
            Debug.LogError("Error saving game results: " + e.Message);
        }

        // Increment game ID for the next game
        gameId++;
    }

    private void ResetGameStats()
    {
        time = 0;
        score = 0;
        errors = 0;
        correctAttempts = 0;
        totalAttempts = 0;
        UpdateTimeLabel();
    }

    private void PreloadCardImage()
    {
        for (int i = 0; i < sprites.Length; i++)
            spritePreload.SpriteID = i;
        spritePreload.gameObject.SetActive(false);
    }

    public void StartCardGame()
    {
        gameSize = Mathf.Min(gameSize, 6);
        if (gameStart) return;
        gameStart = true;
        panel.SetActive(true);
        info.SetActive(false);
        SetGamePanel();
        cardSelected = spriteSelected = -1;
        cardLeft = cards.Length;
        SpriteCardAllocation();
        StartCoroutine(HideFace());
        time = 0;
    }

    private void SetGamePanel()
    {
        int isOdd = gameSize % 2;
        gameSize = Mathf.Min(gameSize, 6);
        cards = new _Card[gameSize * gameSize - isOdd];
        foreach (Transform child in cardList.transform)
        {
            GameObject.Destroy(child.gameObject);
        }

        RectTransform panelsize = panel.transform.GetComponent(typeof(RectTransform)) as RectTransform;
        float row_size = panelsize.sizeDelta.x;
        float col_size = panelsize.sizeDelta.y;
        float scale = 1.0f / gameSize;
        float xInc = row_size / gameSize;
        float yInc = col_size / gameSize;
        float curX = -xInc * (float)(gameSize / 2);
        float curY = -yInc * (float)(gameSize / 2);
        if (isOdd == 0)
        {
            curX += xInc / 2;
            curY += yInc / 2;
        }
        float initialX = curX;

        for (int i = 0; i < gameSize; i++)
        {
            curX = initialX;
            for (int j = 0; j < gameSize; j++)
            {
                GameObject c;
                if (isOdd == 1 && i == (gameSize - 1) && j == (gameSize - 1))
                {
                    int index = gameSize / 2 * gameSize + gameSize / 2;
                    c = cards[index].gameObject;
                }
                else
                {
                    c = Instantiate(prefab);
                    c.transform.SetParent(cardList.transform, false);
                    int index = i * gameSize + j;
                    cards[index] = c.GetComponent<_Card>();
                    cards[index].ID = index;
                    c.transform.localScale = new Vector3(scale, scale);
                }
                c.transform.localPosition = new Vector3(curX, curY, 0);
                curX += xInc;
            }
            curY += yInc;
        }
    }

    void ResetFace()
    {
        for (int i = 0; i < gameSize; i++)
            cards[i].ResetRotation();
    }

    IEnumerator HideFace()
    {
        yield return new WaitForSeconds(1.0f);
        for (int i = 0; i < cards.Length; i++)
            cards[i].Flip();
        yield return new WaitForSeconds(0.5f);
    }

    private void SpriteCardAllocation()
    {
        int i, j;
        int[] selectedID = new int[cards.Length / 2];
        for (i = 0; i < cards.Length / 2; i++)
        {
            int value = Random.Range(0, sprites.Length - 1);
            for (j = i; j > 0; j--)
            {
                if (selectedID[j - 1] == value)
                    value = (value + 1) % sprites.Length;
            }
            selectedID[i] = value;
        }

        for (i = 0; i < cards.Length; i++)
        {
            cards[i].Active();
            cards[i].SpriteID = -1;
            cards[i].ResetRotation();
        }

        for (i = 0; i < cards.Length / 2; i++)
            for (j = 0; j < 2; j++)
            {
                int value = Random.Range(0, cards.Length - 1);
                while (cards[value].SpriteID != -1)
                    value = (value + 1) % cards.Length;
                cards[value].SpriteID = selectedID[i];
            }
    }

    public void SetGameSize()
    {
        gameSize = (int)sizeSlider.value;
        sizeLabel.text = gameSize + " X " + gameSize;
    }

    public Sprite GetSprite(int spriteId)
    {
        return sprites[spriteId];
    }

    public Sprite CardBack()
    {
        return cardBack;
    }

    public bool canClick()
    {
        if (!gameStart)
            return false;
        return true;
    }

    public void cardClicked(int spriteId, int cardId)
    {
        if (spriteSelected == -1)
        {
            spriteSelected = spriteId;
            cardSelected = cardId;
        }
        else
        {
            totalAttempts++;

            if (spriteSelected == spriteId)
            {
                correctAttempts++;
                cards[cardSelected].Inactive();
                cards[cardId].Inactive();
                cardLeft -= 2;
                CheckGameWin();
            }
            else
            {
                errors++;
                cards[cardSelected].Flip();
                cards[cardId].Flip();
            }

            // Update score only if totalAttempts > 0 to avoid NaN
            if (totalAttempts > 0)
                score = (float)correctAttempts / totalAttempts * 100;
            else
                score = 0;

            UpdateTimeLabel();

            cardSelected = spriteSelected = -1;
        }
    }

    private void CheckGameWin()
    {
        if (cardLeft == 0)
        {
            EndGame();
        }
    }

    private void EndGame()
    {
        gameStart = false;
        panel.SetActive(false);
        SaveGameResults();

        // Predict and display performance
        int level = gameSize;
        float timeTaken = time;
        int totalErrors = errors;
        float finalScore = score;

        FindObjectOfType<PredictGamePerformance>().PredictPerformance(level, timeTaken, totalErrors, finalScore);

        StartCoroutine(DisplayFinalStats());
    }

    private IEnumerator DisplayFinalStats()
    {
        timeLabel.text = "Final Time: " + time.ToString("F0") + "s | Final Score: " + score.ToString("F2") + "%";
        yield return new WaitForSeconds(5f);
        ResetGameStats();
    }

    public void GiveUp()
    {
        EndGame();
    }

    public void DisplayInfo(bool i)
    {
        info.SetActive(i);
    }

    private void Update()
    {
        if (gameStart)
        {
            time += Time.deltaTime;
            UpdateTimeLabel();
        }
    }

    private void UpdateTimeLabel()
    {
        timeLabel.text = "Time: " + time.ToString("F0") + "s | Score: " + score.ToString("F2") + "%";
    }
}
